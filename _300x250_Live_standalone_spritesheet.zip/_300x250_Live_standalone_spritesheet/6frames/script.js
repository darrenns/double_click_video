
var adDiv;
var loop = 1;
var legal;
var text_1;
var text_2;
var logo;
var marketLogo;
var icecream;
var bgImage;
var imgShine;
var ctaBtn;

function initEB() {
    startAd();  
}

function startAd() {
    adDiv = document.getElementById("ad");
    legal = document.getElementById("legal");
    text_1 = document.getElementById("text_1");
    text_2 = document.getElementById("text_2");
    logo = document.getElementById("logo");
    marketLogo = document.getElementById("marketLogo");
    icecream = document.getElementById("icecream");
    bgImage = document.getElementById('bgImage');
    imgShine = document.getElementById('imgShine');
    ctaBtn = document.getElementById('ctaBtn');
    //background_video_Two = document.getElementById('background_video_Two');
    background_spriteSheet = document.getElementById('background_spriteSheet');

    var intro = document.querySelector('.banner');
    var introPlayer = document.querySelector('.banner__video');
    var iOS = /iPad|iPhone|iPod/.test(navigator.platform);
    if (iOS) {
      //intro.style.backgroundImage = 'url("' + introPlayer.poster + '")';
      //introPlayer.style.display = 'none';
    }
    animationReset();
}


window.addEventListener("load", initEB);



function allAnimations(){    
    TweenLite.to(icecream, 3.8, {x:-25, ease: Power3.easeOut, delay:0.3});

    //TweenLite.to(background_video, 5, {scale:1.1, x:20, ease: Power3.easeOut, delay:0});
    //TweenLite.to(background_video_Two, 5, {scale:1.1, x:-10, ease: Power3.easeOut, delay:0});
    //TweenLite.to(background_video_Two, 6, {alpha:1, ease: Expo.easeOut, delay:2.5});

    TweenLite.to(background_spriteSheet, 7, {scale:1.1, ease: Power3.easeOut, delay:0});

    


    TweenLite.to(bgImage, 1, {alpha:1, ease: Expo.easeOut, delay:4.8});
    TweenLite.to([logo,legal], 1, { alpha:1, ease: Expo.easeOut, delay:4.8});
    TweenLite.to(logo, 1, {scale:1, ease: Sine.easeOut, delay:4.8});
    TweenLite.to(imgShine, 1, {y:20, x:66, ease: Sine.easeOut, delay:4.8});
    TweenLite.to(text_1, 1, {alpha:1, scale:1, ease: Sine.easeInOut, delay:5.3});
    TweenLite.to(text_2, 1, {alpha:1, scale:1, ease: Sine.easeInOut, delay:5.6});
    TweenLite.to(marketLogo, 1, {alpha:1, ease: Sine.easeOut, delay:6});
    TweenLite.to(ctaBtn, .6, {alpha:1, ease: Expo.easeOut, delay:6.8});
    TweenLite.to(ctaBtn, .8, {scale:1, ease: Elastic.easeOut, delay:6.8});  
}

function animationReset() {
    //TweenLite.to(background_video_Two, 0, {alpha:0});
    TweenLite.to(icecream, 0, {x:-250,alpha:1,y:30});
    TweenLite.to(legal, 0, {y:5,alpha:0});
    TweenLite.to(text_1, 0, {scale:0.98,alpha:0});
    TweenLite.to(text_2, 0, {scale:0.98,alpha:0});
    TweenLite.to(logo, 0, {scale:0.96,alpha:0});
    TweenLite.to(marketLogo, 0, {y:5,alpha:0});
    TweenLite.to(bgImage, 0, {alpha:0});
    TweenLite.to(imgShine, 0, {alpha:1, rotation:45});
    TweenLite.to(ctaBtn, 0, {scale:0.96,alpha:0});
    allAnimations();
}


function loopFnc()
{
    if(loop<2){
            loop++
            TweenLite.to(endFrame, 0.5, {x:0, alpha:0, ease: Power3.easeOut, delay:2, onComplete:animationReset});
            //animationReset();
        }
}



