// JavaScript Document
// JavaScript Document
//HTML5 Ad Template JS from DoubleClick by Google

//Declaring elements from the HTML i.e. Giving them Instance Names like in Flash - makes it easier
var container;
var content;
var bgExit;
var vid1Container;
var vid1;
tlOne = new TimelineLite();
tlTwo = new TimelineLite();
tlThree = new TimelineLite();
//Function to run with any animations starting on load, or bringing in images etc
init = function(){
	//Assign All the elements to the element on the page
	container = document.getElementById('container_dc');
	content = document.getElementById('content_dc');
	bgExit = document.getElementById('background_exit_dc');
	vid1Container = document.getElementById('video1_container_dc');
	vid1 = document.getElementById('vid1');
    mainBackgroundImage = document.getElementById('mainBackgroundImage'); 
    logo = document.getElementById('logo');
     FrameOneTextOne = document.getElementById('FrameOneTextOne');
     FrameOneTextTwo = document.getElementById('FrameOneTextTwo');
     FrameOneTextThree = document.getElementById('FrameOneTextThree');
     FrameTwoTextOne = document.getElementById('FrameTwoTextOne');
     FrameTwoTextTwo = document.getElementById('FrameTwoTextTwo');
     FrameTwoTextThree = document.getElementById('FrameTwoTextThree');
    lastFrame = document.getElementById('lastFrame');
    cta = document.getElementById('cta');
	//Bring in listeners i.e. if a user clicks or rollovers
	addListeners();	
    setPositionsObjects();
    animateAd();
}


//Add Event Listeners
addListeners = function() {
	//bgExit.addEventListener('click', bgExitHandler, false);
	vid1.addEventListener('ended', videoEndHandler, false);

	Enabler.loadModule(studio.module.ModuleId.VIDEO, function() {
	studio.video.Reporter.attach('video_1', vid1);
	});
}


//bgExitHandler = function(e) {
	//Call Exits
//	Enabler.exit('HTML5_Background_Clickthrough');
//	vid1.pause();
  //  console.log("i have exited");
//}

videoEndHandler = function(e) {
    //lastFrame.style.opacity = "1";
	tlThree.to(lastFrame,  1, {opacity:1},"-=1");   
    //vid1.currentTime = 8;
	//vid1.pause();
    animateAdVideoEnded ();
}

window.onload = function() {
  /* Initialize Enabler */
  if (Enabler.isInitialized()) {
    init();
  } else {
    Enabler.addEventListener(studio.events.StudioEvent.INIT, init);
  }
}

        function setPositionsObjects() {
            FrameOneTextOne.style.opacity = "1";
            FrameOneTextTwo.style.opacity = "1";
            FrameOneTextThree.style.opacity = "1";
            FrameTwoTextOne.style.opacity = "0";
            FrameTwoTextTwo.style.opacity = "0";
            FrameTwoTextThree.style.opacity = "0";
            cta.style.opacity = "1";
			cta.style.opacity = "0";
        }


function animateAd (){
    if (navigator.userAgent.match(/(iPhone|iPod|iPad|Android|BlackBerry|IEMobile)/)) {
            vid1Container.style.opacity = "1";
            tlOne.to(logo, 1, {opacity:1, delay:7, ease: Power1.easeOut},"-=0")
            .to(FrameTwoTextOne, 0.7, {opacity:1, delay:4, x:200, ease: Power1.easeOut},"-=1")
            .to(FrameTwoTextTwo, 0.7, {opacity:1, delay:0, x:200, ease: Power1.easeOut},"-=0.5")
            .to(FrameTwoTextThree, 0.7, {opacity:1, delay:0, x:200, ease: Power1.easeOut},"-=0.1")
            .to(lastFrame,  1, {opacity:1},"-=1")
            .to(cta, 0.5, {opacity:1, x:235, delay:1},"-=0.5");
} else {
     vid1.play();
     tlOne.to(vid1Container, 0, {opacity:1, delay:0, ease: Power1.easeOut},"-=0")
     .to(logo, 1, {opacity:1, delay:4, ease: Power1.easeOut},"-=0")
}
    
    
         
}


function animateAdVideoEnded (){
            tlTwo.to(cta, 0.2, {opacity:1, x:235, delay:0},"-=1.5");          
}








