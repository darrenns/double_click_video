
var adDiv;
var loop = 1;
var legal;
var text_1;
var text_2;
var vid1;
var logo;
var marketLogo;
var bgImage;
var imgShine;
var ctaBtn;

function initEB() {
    startAd();
    bgExit = document.getElementById('clickthrough');
}

function startAd() {
    adDiv = document.getElementById("ad");
    legal = document.getElementById("legal");
    text_1 = document.getElementById("text_1");
    text_2 = document.getElementById("text_2");
    logo = document.getElementById("logo");
    vid1 = document.getElementById('vid1');
    marketLogo = document.getElementById("marketLogo");
    bgImage = document.getElementById('bgImage');
    imgShine = document.getElementById('imgShine');
    ctaBtn = document.getElementById('ctaBtn');
    var intro = document.querySelector('.banner');
    var introPlayer = document.querySelector('.banner__video');
    var iOS = /iPad|iPhone|iPod/.test(navigator.platform);
    if (iOS) {
      //intro.style.backgroundImage = 'url("' + introPlayer.poster + '")';
      //introPlayer.style.display = 'none';
    }
    addListeners(); 
    animationReset();
}

//Add Event Listeners
addListeners = function() {
    //bgExit.addEventListener('click', bgExitHandler, false);
    //vid1.addEventListener('ended', videoEndHandler, false);

    Enabler.loadModule(studio.module.ModuleId.VIDEO, function() {
    studio.video.Reporter.attach('video_1', vid1);
    });
}

window.onload = function() {
  /* Initialize Enabler */
  if (Enabler.isInitialized()) {
    initEB();
  } else {
    Enabler.addEventListener(studio.events.StudioEvent.INIT, initEB);
  }
}
//window.addEventListener("load", initEB);


function allAnimations(){
    TweenLite.to(bgImage, 1, {alpha:1, ease: Expo.easeOut, delay:8});
    TweenLite.to([logo,legal], 1, { alpha:1, ease: Expo.easeOut, delay:8});
    TweenLite.to(logo, 1, {scale:1, ease: Sine.easeOut, delay:8});
    TweenLite.to(imgShine, 1, {y:20, x:66, ease: Sine.easeOut, delay:8});
    TweenLite.to(text_1, 1, {alpha:1, scale:1, ease: Sine.easeInOut, delay:8.5});
    TweenLite.to(text_2, 1, {alpha:1, scale:1, ease: Sine.easeInOut, delay:8.8});
    TweenLite.to(marketLogo, 1, {alpha:1, ease: Sine.easeOut, delay:9.2});
    TweenLite.to(ctaBtn, .6, {alpha:1, ease: Expo.easeOut, delay:10});
    TweenLite.to(ctaBtn, .8, {scale:1, ease: Elastic.easeOut, delay:10});    
}

function animationReset() { 
    TweenLite.to(legal, 0, {y:5,alpha:0});
    TweenLite.to(text_1, 0, {scale:0.98,alpha:0});
    TweenLite.to(text_2, 0, {scale:0.98,alpha:0});
    TweenLite.to(logo, 0, {scale:0.96,alpha:0});
    TweenLite.to(marketLogo, 0, {y:5,alpha:0});
    TweenLite.to(bgImage, 0, {alpha:0});
    TweenLite.to(imgShine, 0, {alpha:1, rotation:45});
    TweenLite.to(ctaBtn, 0, {scale:0.96,alpha:0});
    allAnimations();
}

function loopFnc() {
    if(loop<2){
            loop++
            TweenLite.to(endFrame, 0.5, {x:0, alpha:0, ease: Power3.easeOut, delay:2, onComplete:animationReset});
            //animationReset();
        }
}



